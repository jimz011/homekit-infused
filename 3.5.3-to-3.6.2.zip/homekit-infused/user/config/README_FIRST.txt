Do NOT EVER delete any of these files or HKI will most certainly break.

Do NOT EVER delete or comment out the first line of the files in this folder.

Any change to the files in this folder requires a restart of Home Assistant!